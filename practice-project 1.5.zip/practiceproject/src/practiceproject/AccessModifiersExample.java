package practiceproject;
//Main class
public class AccessModifiersExample {
 public static void main(String[] args) {
     // Creating an instance of MyClass
     MyClass myObject = new MyClass();

     // Accessing members with different access modifiers
     myObject.publicMethod();    // Accessible everywhere
     myObject.protectedMethod(); // Accessible within the same package and subclasses
     myObject.defaultMethod();   // Accessible only within the same package
     // Uncommenting the line below would result in a compilation error
     // myObject.privateMethod(); // Accessible only within the same class
 }
}

//MyClass with different access modifiers
class MyClass {
 // Public method
 public void publicMethod() {
     System.out.println("Public method");
 }

 // Protected method
 protected void protectedMethod() {
     System.out.println("Protected method");
 }

 // Default (package-private) method
 void defaultMethod() {
     System.out.println("Default method");
 }

 // Private method
 private void privateMethod() {
     System.out.println("Private method");
 }
}